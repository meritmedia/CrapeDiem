﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrapeDiem
{
    class Score
    {
        public int Player { get; set; }
        public int Turn { get; set; }
        public int CardPoint { get; set; }
        public int Roll { get; set; }
        public int DieOne { get; set; }
        public int DieTwo { get; set; }
        public int Points { get; set; }
        public Score()
        {
         
        }
    }
}
